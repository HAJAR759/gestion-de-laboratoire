package com.ProjetLibre.ProjetLibre;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetLibreApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetLibreApplication.class, args);
	}

}
